﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ButtonBehaviour : MonoBehaviour
{

    public GameObject menu;
    public GameObject menuSettings;

    //in the class:

    public void PlayGame()
    {
        Application.LoadLevel("Scene 0");
    }

    public void QuitGame()
    {
//        menu.active = false;
//        menuSettings.active = true;
//        Application.LoadLevel("Scene 1");
          Application.Quit();
    }
   
}
